# Mahjong Bot v0.1

Prototype Android app for UI + State Machine + Trigger + Simulator.

## Included
- Dashboard
- Settings
- Event log
- State machine
- Profit / loss session tracking
- Stop profit
- Stop loss
- Losing streak recovery trigger
- Simulation-only spin button

## Not included
- Auto-tap
- Accessibility automation
- OCR / computer vision
- RNG prediction
- PG SOFT integration

## Build
Open the project in Android Studio, allow Gradle sync, then:
Build > Build APK(s)

The debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk
