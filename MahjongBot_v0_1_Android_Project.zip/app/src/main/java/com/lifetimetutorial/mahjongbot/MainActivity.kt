package com.lifetimetutorial.mahjongbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

enum class BotState { INIT, READY, SPINNING, RESULT, WIN, LOSS, RECOVERY, STOP_PROFIT, STOP_LOSS, ERROR }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MahjongBotApp() }
    }
}

@Composable
fun MahjongBotApp() {
    var balance by remember { mutableDoubleStateOf(1_000_000.0) }
    var session by remember { mutableDoubleStateOf(0.0) }
    var spin by remember { mutableIntStateOf(0) }
    var wins by remember { mutableIntStateOf(0) }
    var losses by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf(BotState.READY) }
    var botOn by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var logs by remember { mutableStateOf(listOf("INIT → READY")) }

    val bet = 1_000.0
    val target = 100_000.0
    val stopLoss = 100_000.0

    fun log(s: String) { logs = (logs + s).takeLast(40) }

    fun reset() {
        balance = 1_000_000.0; session = 0.0; spin = 0
        wins = 0; losses = 0; streak = 0
        state = BotState.READY; botOn = false
        logs = listOf("SESSION RESET", "INIT → READY")
    }

    fun simulateSpin() {
        if (!botOn || state == BotState.STOP_PROFIT || state == BotState.STOP_LOSS) return
        state = BotState.SPINNING
        spin++
        log("SPIN #$spin → SPINNING")

        val win = Random.nextInt(100) < 45
        state = BotState.RESULT
        log("SPIN #$spin → RESULT")

        if (win) {
            val payout = bet * Random.nextInt(2, 7)
            balance += payout - bet
            session += payout - bet
            wins++
            streak = 0
            state = BotState.WIN
            log("RESULT = WIN +Rp${(payout - bet).toInt()}")
        } else {
            balance -= bet
            session -= bet
            losses++
            streak++
            state = BotState.LOSS
            log("RESULT = LOSS -Rp${bet.toInt()}")
        }

        if (session >= target) {
            state = BotState.STOP_PROFIT
            botOn = false
            log("TRIGGER → STOP_PROFIT")
        } else if (session <= -stopLoss) {
            state = BotState.STOP_LOSS
            botOn = false
            log("TRIGGER → STOP_LOSS")
        } else if (streak >= 5) {
            state = BotState.RECOVERY
            log("TRIGGER → RECOVERY (LOSS STREAK 5)")
            state = BotState.READY
        } else {
            state = BotState.READY
        }
        log("STATE → $state")
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF22C55E),
            background = Color(0xFF0B1020),
            surface = Color(0xFF111827)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
            ) {
                Text("MAHJONG BOT v0.1", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("SIMULATION MODE", color = Color(0xFF22C55E), fontSize = 12.sp)

                Spacer(Modifier.height(16.dp))

                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("STATE", fontSize = 12.sp)
                        Text(state.name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Balance  Rp${balance.toInt()}")
                        Text("Session  Rp${session.toInt()}")
                        Text("Spin     $spin")
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("WIN", wins.toString(), Modifier.weight(1f))
                    StatCard("LOSS", losses.toString(), Modifier.weight(1f))
                    StatCard("STREAK", streak.toString(), Modifier.weight(1f))
                }

                Spacer(Modifier.height(12.dp))

                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("SESSION SETTINGS", fontWeight = FontWeight.Bold)
                        Text("Bet: Rp${bet.toInt()}")
                        Text("Target Profit: Rp${target.toInt()}")
                        Text("Stop Loss: Rp${stopLoss.toInt()}")
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("BOT", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Switch(checked = botOn, onCheckedChange = {
                        botOn = it
                        if (it) { state = BotState.READY; log("BOT ON → READY") }
                        else log("BOT OFF")
                    })
                }

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = { simulateSpin() },
                    enabled = botOn && state != BotState.STOP_PROFIT && state != BotState.STOP_LOSS,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("SIMULATE SPIN") }

                OutlinedButton(onClick = { reset() }, modifier = Modifier.fillMaxWidth()) {
                    Text("RESET SESSION")
                }

                Spacer(Modifier.height(16.dp))

                Row(Modifier.fillMaxWidth()) {
                    TextButton(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("DASHBOARD") }
                    TextButton(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("SETTINGS") }
                    TextButton(onClick = { tab = 2 }, modifier = Modifier.weight(1f)) { Text("LOG") }
                }

                when (tab) {
                    1 -> SettingsPage()
                    2 -> {
                        Text("EVENT LOG", fontWeight = FontWeight.Bold)
                        logs.reversed().forEach { Text(it, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 11.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsPage() {
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("V0.1 SETTINGS", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text("SESSION")
            Text("Starting Balance   Rp1.000.000")
            Text("Target Profit      Rp100.000")
            Text("Stop Loss          Rp100.000")
            Text("Maximum Spin       1000")
            Spacer(Modifier.height(8.dp))
            Text("BET")
            Text("Initial Bet        Rp1.000")
            Text("Bet Mode           FLAT")
            Spacer(Modifier.height(8.dp))
            Text("TRIGGERS")
            Text("Max Losing Streak  5")
            Text("Recovery           ON")
            Text("Error Timeout      10 sec")
            Spacer(Modifier.height(8.dp))
            Text("NOTE: V0.1 is a simulator. It does not control or predict PG SOFT RNG.")
        }
    }
}
